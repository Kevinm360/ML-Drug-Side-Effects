import os
import time
import requests
import streamlit as st
from typing import Dict, Any, Optional

# Compatibility shim for older Streamlit
if not hasattr(st, "cache_data"):
    st.cache_data = st.cache

OPENFDA_BASE = "https://api.fda.gov/drug/event.json"

def _get_api_key() -> Optional[str]:
    try:
        k = st.secrets.get("OPENFDA_API_KEY")  # type: ignore[attr-defined]
        if k:
            return str(k)
    except Exception:
        pass
    return os.getenv("OPENFDA_API_KEY")

# Single session and gentle throttle
_SESSION = requests.Session()

def _request(params: Dict[str, Any]) -> Dict[str, Any]:
    """HTTP GET with small throttle + retry on 429/5xx, honoring Retry-After."""
    key = _get_api_key()
    if key:
        params = {**params, "api_key": key}

    # tiny client-side rate limit
    time.sleep(0.18)  # ~5–6 req/s max

    attempts = 5
    backoff = 0.8
    last = None
    for i in range(attempts):
        r = _SESSION.get(OPENFDA_BASE, params=params, timeout=30)
        if r.status_code == 200:
            return r.json()
        if r.status_code in (429, 500, 502, 503, 504):
            last = r
            ra = r.headers.get("Retry-After")
            try:
                sleep_for = float(ra) if ra is not None else backoff * (i + 1)
            except Exception:
                sleep_for = backoff * (i + 1)
            time.sleep(sleep_for)
            continue
        r.raise_for_status()
    if last is not None:
        last.raise_for_status()
    raise RuntimeError("openFDA request failed with no response")

@st.cache_data(ttl=3600)
def total_count(search: str) -> int:
    """Return meta.results.total for a given search (cached)."""
    js = _request({"search": search, "limit": 1})
    return int(js.get("meta", {}).get("results", {}).get("total", 0))

@st.cache_data(ttl=3600)
def top_reactions(drug_name: str, start: Optional[str] = None, end: Optional[str] = None, n: int = 50):
    """
    Top reaction PTs for a drug.
    - If start/end are provided → limited to that date window.
    - If start/end are None → all-time (backwards compatible).
    Returns DataFrame with columns ["reaction", "reports"].
    """
    if start and end:
        q = f'patient.drug.medicinalproduct:"{drug_name.upper()}" AND receivedate:[{start} TO {end}]'
    else:
        q = f'patient.drug.medicinalproduct:"{drug_name.upper()}"'
    js = _request({"search": q, "count": "patient.reaction.reactionmeddrapt.exact"})
    import pandas as pd
    df = pd.DataFrame(js.get("results", []))
    if df.empty:
        return pd.DataFrame(columns=["reaction", "reports"])
    return df.rename(columns={"term": "reaction", "count": "reports"}).head(n)

@st.cache_data(ttl=3600)
def timeseries(drug_name: str, start: str, end: str):
    """Weekly counts for a drug by receivedate."""
    q = f'patient.drug.medicinalproduct:"{drug_name.upper()}" AND receivedate:[{start} TO {end}]'
    js = _request({"search": q, "count": "receivedate"})
    import pandas as pd
    df = pd.DataFrame(js.get("results", []))
    if df.empty:
        return df.assign(date=pd.to_datetime([]), count=[])
    df["date"] = pd.to_datetime(df["time"])
    df = df[["date", "count"]].sort_values("date")
    return df

@st.cache_data(ttl=3600)
def sample_reports(drug_name: str, n: int = 10):
    q = f'patient.drug.medicinalproduct:"{drug_name.upper()}"'
    js = _request({"search": q, "limit": max(1, min(int(n), 1000))})
    rows = []
    for r in js.get("results", []):
        p = r.get("patient", {}) or {}
        rx = p.get("reaction", []) or []
        dr = p.get("drug", []) or []
        rows.append({
            "safetyreportid": r.get("safetyreportid"),
            "receivedate": r.get("receivedate"),
            "drug_name": (dr[0] or {}).get("medicinalproduct") if dr else None,
            "reactions": ", ".join(x.get("reactionmeddrapt", "") for x in rx if x.get("reactionmeddrapt")),
            "sex": p.get("patientsex"),
            "age": p.get("patientonsetage"),
        })
    import pandas as pd
    return pd.DataFrame(rows)

@st.cache_data(ttl=3600)
def popular_drugs(start: str, end: str, n: int = 200):
    """Popular drug names in the window."""
    q = f'receivedate:[{start} TO {end}]'
    js = _request({"search": q, "count": "patient.drug.medicinalproduct.exact"})
    import pandas as pd
    df = pd.DataFrame(js.get("results", []))
    if df.empty:
        return ["METFORMIN"]
    return [t for t in df["term"].head(n).tolist() if isinstance(t, str)]

@st.cache_data(ttl=3600)
def reaction_counts_all(start: str, end: str, limit: int = 1000) -> Dict[str, int]:
    """Total reports per reaction PT (all drugs) within the window."""
    js = _request({
        "search": f"receivedate:[{start} TO {end}]",
        "count": "patient.reaction.reactionmeddrapt.exact",
        "limit": max(1, min(int(limit), 1000)),
    })
    results = js.get("results", []) or []
    return {row.get("term"): int(row.get("count", 0)) for row in results if row.get("term")}
@st.cache_data(ttl=3600)
def reaction_counts_all_serious(start: str, end: str, limit: int = 1000) -> Dict[str, int]:
    """
    Serious-only totals per reaction PT (all drugs) within the window.
    Returns {REACTION_UPPER: count}.
    """
    js = _request({
        "search": f"serious:1 AND receivedate:[{start} TO {end}]",
        "count": "patient.reaction.reactionmeddrapt.exact",
        "limit": max(1, min(int(limit), 1000)),
    })
    results = js.get("results", []) or []
    return { (row.get("term") or "").upper(): int(row.get("count", 0))
             for row in results if row.get("term") }

@st.cache_data(ttl=3600)
def reaction_counts_for_drug(drug_name: str, start: str, end: str, flag: Optional[str] = None, limit: int = 1000) -> Dict[str, int]:
    """
    Count reactions for a single drug in a window, optionally filtered by a flag
    like 'serious:1' or 'seriousnessdeath:1'. Returns {REACTION_UPPER: count}.
    """
    base = f'patient.drug.medicinalproduct:"{drug_name.upper()}" AND receivedate:[{start} TO {end}]'
    if flag:
        base = f"{base} AND {flag}"
    js = _request({
        "search": base,
        "count": "patient.reaction.reactionmeddrapt.exact",
        "limit": max(1, min(int(limit), 1000)),
    })
    results = js.get("results", []) or []
    return { (row.get("term") or "").upper(): int(row.get("count", 0))
             for row in results if row.get("term") }
