import pandas as pd
from typing import Dict
from faers_client import total_count
import streamlit as st

@st.cache_data(ttl=3600)
def _drug_total(drug: str, start: str, end: str) -> int:
    q = f'patient.drug.medicinalproduct:"{drug.upper()}" AND receivedate:[{start} TO {end}]'
    return total_count(q)

@st.cache_data(ttl=3600)
def _rx_total(reaction: str, start: str, end: str) -> int:
    q = f'patient.reaction.reactionmeddrapt:"{reaction.upper()}" AND receivedate:[{start} TO {end}]'
    return total_count(q)

@st.cache_data(ttl=3600)
def _all_total(start: str, end: str) -> int:
    q = f'receivedate:[{start} TO {end}]'
    return total_count(q)

def _prr_ror_chi2(a: int, b: int, c: int, d: int) -> Dict[str, float]:
    a1, b1, c1, d1 = (x if x > 0 else 0.5 for x in (a, b, c, d))
    prr = (a1 / (a1 + b1)) / (c1 / (c1 + d1))
    ror = (a1 * d1) / (b1 * c1)
    denom = (a + b) * (c + d) * (a + c) * (b + d)
    chi2 = ((a * d - b * c) ** 2) * (a + b + c + d) / denom if denom else 0.0
    return {"prr": float(prr), "ror": float(ror), "chi2": float(chi2)}

def _is_signal(a: int, prr: float, chi2: float) -> bool:
    return (a >= 3) and (prr >= 2.0) and (chi2 >= 4.0)

def score_reactions(
    drug: str,
    reactions: pd.Series,
    start: str,
    end: str,
    *,
    a_counts: Dict[str, int] | None = None,
    rx_totals: Dict[str, int] | None = None,   # NEW
    top_n: int = 15,
) -> pd.DataFrame:
    """Compute disproportionality stats with optional rx_totals to save calls."""
    if a_counts is None:
        a_counts = {}
    rx_list = reactions.dropna().astype(str).unique().tolist()[:top_n]

    drug_total = _drug_total(drug, start, end)
    all_total  = _all_total(start, end)
    rx_totals = rx_totals or {}

    rows = []
    for rx in rx_list:
        a = int(a_counts.get(rx, 0))
        if a == 0:
            a = total_count(
                f'patient.drug.medicinalproduct:"{drug.upper()}" AND '
                f'patient.reaction.reactionmeddrapt:"{rx.upper()}" AND '
                f'receivedate:[{start} TO {end}]'
            )

        rx_total = rx_totals.get(rx)
        if rx_total is None:
            rx_total = _rx_total(rx, start, end)

        b = max(drug_total - a, 0)
        c = max(rx_total - a, 0)
        d = max(all_total - a - b - c, 0)

        stats = _prr_ror_chi2(a, b, c, d)
        rows.append({
            "reaction": rx, "a": a, "b": b, "c": c, "d": d,
            "prr": stats["prr"], "ror": stats["ror"], "chi2": stats["chi2"],
            "signal": _is_signal(a, stats["prr"], stats["chi2"]),
        })

    df = pd.DataFrame(rows)
    if df.empty:
        return pd.DataFrame(columns=["reaction","a","b","c","d","prr","ror","chi2","signal"])
    return df.sort_values(["signal","prr","chi2"], ascending=[False, False, False]).reset_index(drop=True)

def burst_zscores(ts: pd.DataFrame, window: int = 8) -> pd.DataFrame:
    if ts is None or ts.empty:
        return ts
    df = ts.copy()
    df["mean"] = df["count"].rolling(window, min_periods=window//2).mean()
    df["std"]  = df["count"].rolling(window, min_periods=window//2).std()
    df["z"]    = (df["count"] - df["mean"]) / df["std"]
    return df
