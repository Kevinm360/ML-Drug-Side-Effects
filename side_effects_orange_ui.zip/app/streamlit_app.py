# app/streamlit_app.py
import sys, pathlib
import io, json, zipfile
import math
from datetime import date, timedelta

import streamlit as st
import pandas as pd
import altair as alt
import numpy as np
import plotly.graph_objects as go

# Allow local imports (faers_client, ml_signal live next to this file)
sys.path.insert(0, str(pathlib.Path(__file__).parent.resolve()))

from faers_client import (
    timeseries as faers_timeseries,
    top_reactions as faers_top,
    sample_reports as faers_samples,
    popular_drugs as faers_popular,
    reaction_counts_all,  # aggregate PT totals across all drugs
)
from ml_signal import score_reactions, burst_zscores

# ---------- MUST be the first Streamlit call ----------
st.set_page_config(page_title="Side-Effects Signal Monitor — FAERS", layout="wide")

# ---------- Theme / CSS ----------
def inject_ui_theme():
    st.markdown(
        """
    <style>
      /* App-wide warm gradient */
      .stApp {
        background: linear-gradient(135deg, #ff3d00 0%, #ff7a00 40%, #ffb300 70%, #ffd200 100%) fixed;
      }
      [data-testid="stAppViewContainer"] > .main { background: transparent; }
      [data-testid="stHeader"] { background: transparent; }
      [data-testid="stSidebar"] { background: rgba(0,0,0,0.20); backdrop-filter: blur(8px); }

      /* Compact chat bubbles (if using st.chat_message) */
      :root{ --bubble-max:640px; --bubble-pad:8px 12px; --bubble-radius:12px; --bubble-font:.92rem; }
      [data-testid="stChatMessageList"] { gap:.35rem !important; }
      [data-testid="stChatMessage"]{ max-width:var(--bubble-max); margin:.1rem 0; }
      [data-testid="stChatMessage"] > div:nth-child(2){
        padding:var(--bubble-pad); border-radius:var(--bubble-radius); font-size:var(--bubble-font);
        line-height:1.35; border:1px solid rgba(255,255,255,.16);
        background:rgba(0,0,0,.18); backdrop-filter: blur(6px);
      }
      [data-testid="stChatMessage"]:has(svg[data-testid="stChatMessageAvatarUser"]) > div:nth-child(2){ background: rgba(255,255,255,.14); }
      [data-testid="stChatMessage"]:has(svg[data-testid="stChatMessageAvatarAssistant"]) > div:nth-child(2){ background: rgba(0,0,0,.22); }

      /* Slightly smaller code text inside messages */
      [data-testid="stChatMessage"] pre, [data-testid="stChatMessage"] code { font-size:.86rem; }

      /* Make metric/stat cards translucent so gradient peeks through (class names may vary by build) */
      .st-emotion-cache-1wmy9hl, .st-emotion-cache-1r6slb0, .st-emotion-cache-16idsys {
        background: rgba(255,255,255,0.06) !important;
        border: 1px solid rgba(255,255,255,0.12) !important;
        backdrop-filter: blur(6px);
      }
    </style>
        """,
        unsafe_allow_html=True,
    )

inject_ui_theme()

# ---------- Title / caption ----------
st.title("💊 Side-Effects Signal Monitor — FAERS (openFDA data only)")
st.caption(
    "Live adverse-event reports via openFDA drug/event API. "
    "Add an `OPENFDA_API_KEY` in Secrets or env to raise limits."
)

# ---------- helpers ----------
def _trigger_fetch():
    """Mark that we need to refetch from the API on the next rerun."""
    st.session_state["fetch"] = True

def _params_tuple():
    return (
        st.session_state.get("drug_final"),
        st.session_state.get("start"),
        st.session_state.get("end"),
        st.session_state.get("compare_on"),
        st.session_state.get("drug_b") if st.session_state.get("compare_on") else None,
    )

def _render_svg(chart, use_container_width=True):
    """Render Altair as SVG and inline data so Streamlit always sees it."""
    spec = chart.to_dict()
    try:
        if isinstance(spec.get("data"), dict) and "name" in spec["data"] and "datasets" in spec:
            name = spec["data"]["name"]
            values = spec["datasets"].get(name)
            if values is not None:
                spec["data"] = {"values": values}
                spec.pop("datasets", None)
    except Exception:
        pass
    meta = spec.get("usermeta", {})
    embed = meta.get("embedOptions", {})
    embed["renderer"] = "svg"
    meta["embedOptions"] = embed
    spec["usermeta"] = meta
    st.vega_lite_chart(spec, use_container_width=use_container_width)

def _do_fetch():
    """Fetch all data needed for the current selections (and compare drug if set)."""
    params = _params_tuple()
    if st.session_state.get("last_params") == params:
        return

    drug  = st.session_state["drug_final"]
    start = st.session_state["start"]
    end   = st.session_state["end"]

    # Timeseries
    try:
        ts = faers_timeseries(drug, start, end)
    except Exception as e:
        st.error(f"Timeseries query failed: {e}")
        ts = None
    st.session_state["ts"] = ts

    # Top reactions
    try:
        tr = faers_top(drug, start, end, 50)
    except Exception as e:
        st.error(f"Top reactions query failed: {e}")
        tr = None
    st.session_state["tr"] = tr

    # Sample reports
    try:
        sr = faers_samples(drug, 20)
    except Exception as e:
        st.error(f"Sample reports query failed: {e}")
        sr = None
    st.session_state["sr"] = sr

    # ML: burst z-scores on timeseries
    st.session_state["ts_bursts"] = burst_zscores(ts)

    # ML: disproportionality on top reactions
    if isinstance(tr, pd.DataFrame) and not tr.empty:
        a_map = dict(zip(tr["reaction"].astype(str), tr["reports"].astype(int)))
        try:
            rx_totals = reaction_counts_all(start, end, limit=1000)
        except Exception:
            rx_totals = {}
        st.session_state["signals"] = score_reactions(
            drug,
            tr["reaction"],
            start,
            end,
            a_counts=a_map,
            rx_totals=rx_totals,
            top_n=100
        )
    else:
        st.session_state["signals"] = pd.DataFrame()

    # Optional compare drug
    st.session_state["ts_b"] = None
    if st.session_state.get("compare_on") and st.session_state.get("drug_b"):
        try:
            st.session_state["ts_b"] = faers_timeseries(st.session_state["drug_b"], start, end)
        except Exception as e:
            st.error(f"Compare mode failed: {e}")

    st.session_state["last_params"] = params

    # Bookmark current state in the URL
    try:
        st.query_params.clear()
        st.query_params.update(
            start=st.session_state.get("start",""),
            end=st.session_state.get("end",""),
            drug=st.session_state.get("drug_final",""),
            compare=st.session_state.get("drug_b","") if st.session_state.get("compare_on") else "",
            auto="1" if st.session_state.get("auto_fetch", True) else "0",
        )
    except Exception:
        pass

# ---------- Sidebar ----------
st.sidebar.header("Filters")

today = date.today()
start_default = (today - timedelta(days=180)).strftime("%Y%m%d")
end_default   = today.strftime("%Y%m%d")

# Auto-fetch toggle
st.sidebar.toggle("Auto-fetch on change", value=True, key="auto_fetch")

# Dates
st.sidebar.text_input(
    "Start (YYYYMMDD)", start_default, key="start",
    on_change=_trigger_fetch if st.session_state.get("auto_fetch", True) else None
)
st.sidebar.text_input(
    "End (YYYYMMDD)", end_default, key="end",
    on_change=_trigger_fetch if st.session_state.get("auto_fetch", True) else None
)

# Drug suggestions
st.sidebar.caption("Pick from recent FAERS drugs or type your own")
try:
    suggestions = faers_popular(st.session_state["start"], st.session_state["end"], 200)
except Exception:
    suggestions = ["METFORMIN"]

st.sidebar.selectbox(
    "Drug (medicinal product)",
    options=["METFORMIN"] + [s for s in suggestions if s != "METFORMIN"],
    index=0, key="drug_select",
    on_change=_trigger_fetch if st.session_state.get("auto_fetch", True) else None
)
st.sidebar.text_input(
    "…or type a drug name", key="drug_manual",
    on_change=_trigger_fetch if st.session_state.get("auto_fetch", True) else None
)

# Final drug to use
st.session_state["drug_final"] = (st.session_state.get("drug_manual") or "").strip() or st.session_state["drug_select"]

# Compare mode
with st.sidebar.expander("Compare two drugs"):
    st.checkbox(
        "Enable compare mode", key="compare_on",
        on_change=_trigger_fetch if st.session_state.get("auto_fetch", True) else None
    )
    if st.session_state.get("compare_on"):
        st.text_input(
            "Second drug (optional)", "IBUPROFEN", key="drug_b",
            on_change=_trigger_fetch if st.session_state.get("auto_fetch", True) else None
        )

# ---------- Unified fetch logic ----------
if "initialized" not in st.session_state:
    st.session_state["initialized"] = True
    st.session_state["fetch"] = True

if not st.session_state.get("auto_fetch", True):
    if st.button("Fetch from openFDA", type="primary", use_container_width=True):
        st.session_state["fetch"] = True

if st.session_state.get("auto_fetch", True) or st.session_state.get("fetch"):
    with st.spinner("Loading from openFDA…"):
        _do_fetch()
    st.session_state["fetch"] = False

# ---------- Render ----------
ts  = st.session_state.get("ts")
tr  = st.session_state.get("tr")
sr  = st.session_state.get("sr")
tsb = st.session_state.get("ts_b")
sig = st.session_state.get("signals")
tsz = st.session_state.get("ts_bursts")

if isinstance(ts, pd.DataFrame) and not ts.empty:
    k1, k2, k3 = st.columns(3)
    total = int(ts["count"].sum())
    last  = int(ts["count"].iloc[-1])
    delta = int(last - ts["count"].iloc[-2]) if len(ts) > 1 else 0
    k1.metric("Total reports", f"{total:,}")
    k2.metric("Last week", f"{last:,}", delta=delta)
    k3.metric("Weeks", len(ts))
else:
    st.info("Pick a drug and date window to load real FAERS data.")

overview_tab, reactions_tab, reports_tab, signals_tab = st.tabs(
    ["Overview", "Reactions", "Reports", "Signals"]
)

# ----- Overview (SVG line chart) -----
with overview_tab:
    drug = st.session_state["drug_final"]
    st.subheader(f"Weekly FAERS reports — {drug}")
    if ts is None or ts.empty:
        st.caption("No reports in that window.")
    else:
        line = (
            alt.Chart(ts)
            .mark_line(strokeWidth=2)
            .encode(
                x=alt.X("date:T", title="Week"),
                y=alt.Y("count:Q", title="Weekly reports"),
                tooltip=[alt.Tooltip("date:T"), alt.Tooltip("count:Q", format=",")]
            )
            .properties(height=320, width="container")
            .configure_axis(labelFontSize=12, titleFontSize=12)
            .configure_view(strokeWidth=0)
        )
        _render_svg(line)
        st.dataframe(ts.rename(columns={"count": "weekly_reports"}), use_container_width=True, height=220)

        if isinstance(tsz, pd.DataFrame) and not tsz.empty:
            bursts = tsz[tsz["z"] > 3].copy()
            if not bursts.empty:
                st.warning(f"Detected {len(bursts)} burst(s) (z > 3). Showing latest:")
                st.dataframe(bursts[["date", "count", "z"]].tail(8), use_container_width=True)

    # Compare overlay (SVG lines)
    if ts is not None and not ts.empty and tsb is not None and not tsb.empty:
        drug_b = st.session_state.get("drug_b")
        a = ts.assign(series=drug).rename(columns={"count": "value"})[["date","series","value"]]
        b = tsb.assign(series=drug_b).rename(columns={"count": "value"})[["date","series","value"]]
        tidy = pd.concat([a, b], ignore_index=True)

        st.subheader(f"Weekly reports: {drug} vs {drug_b}")
        comp = (
            alt.Chart(tidy)
            .mark_line(strokeWidth=2)
            .encode(
                x=alt.X("date:T", title="Week"),
                y=alt.Y("value:Q", title="Weekly reports"),
                color=alt.Color("series:N", title="Drug"),
                tooltip=[alt.Tooltip("date:T"), "series:N", alt.Tooltip("value:Q", format=",")]
            )
            .properties(height=320, width="container")
            .configure_axis(labelFontSize=12, titleFontSize=12)
            .configure_view(strokeWidth=0)
        )
        _render_svg(comp)

# ----- Reactions (treemap only) -----
with reactions_tab:
    st.subheader("Top reactions")
    if isinstance(tr, pd.DataFrame) and not tr.empty:
        top_n = st.slider("How many reactions to show (Top N)",
                          min_value=5, max_value=min(50, len(tr)),
                          value=min(20, len(tr)), step=1,
                          help="Adjust to see more/less reactions.")
        df_rx = tr.sort_values("reports", ascending=False).head(top_n).copy()

        import plotly.express as px
        fig = px.treemap(
            df_rx, path=["reaction"], values="reports",
            color="reports", color_continuous_scale="Blues",
        )
        fig.update_layout(margin=dict(l=0, r=0, t=10, b=0),
                          height=420, coloraxis_showscale=False)
        if fig.data:
            fig.data[0].hovertemplate = "<b>%{label}</b><br>Reports: %{value:,}<extra></extra>"
        st.plotly_chart(fig, use_container_width=True, theme=None)

        st.dataframe(df_rx.reset_index(drop=True), use_container_width=True, height=320)
    else:
        st.caption("No reaction data for this window. Try expanding the date range.")

# ----- Reports -----
with reports_tab:
    st.subheader("Sample raw reports")
    if isinstance(sr, pd.DataFrame) and not sr.empty:
        st.dataframe(sr, use_container_width=True, height=420)
        st.download_button("Download samples (CSV)", sr.to_csv(index=False),
                           "faers_samples.csv", "text/csv")
    else:
        st.caption("No sample reports returned.")

    # one-click “case bundle” ZIP
    try:
        params = {
            "drug": st.session_state.get("drug_final"),
            "compare_drug": st.session_state.get("drug_b") if st.session_state.get("compare_on") else "",
            "start": st.session_state.get("start"),
            "end": st.session_state.get("end"),
            "generated_at": pd.Timestamp.utcnow().isoformat(),
        }
        weekly_df    = st.session_state.get("ts")
        reactions_df = st.session_state.get("tr")
        signals_df   = st.session_state.get("signals")
        mem = io.BytesIO()
        with zipfile.ZipFile(mem, mode="w", compression=zipfile.ZIP_DEFLATED) as z:
            z.writestr("params.json", json.dumps(params, indent=2))
            if isinstance(weekly_df, pd.DataFrame) and not weekly_df.empty:
                z.writestr("weekly_timeseries.csv", weekly_df.to_csv(index=False))
            if isinstance(reactions_df, pd.DataFrame) and not reactions_df.empty:
                z.writestr("top_reactions.csv", reactions_df.to_csv(index=False))
            if isinstance(signals_df, pd.DataFrame) and not signals_df.empty:
                z.writestr("signals_scored.csv", signals_df.to_csv(index=False))
        st.download_button(
            "📦 Download case bundle (ZIP)",
            data=mem.getvalue(),
            file_name=f"{st.session_state.get('drug_final','drug')}_{st.session_state.get('start','')}_{st.session_state.get('end','')}.zip",
            mime="application/zip"
        )
    except Exception as e:
        st.caption(f"Bundle export unavailable: {e}")

# ----- Signals -----
with signals_tab:
    st.subheader("Disproportionality signals (PRR / ROR / χ²)")
    st.caption("Flags use a simple MHRA-like rule: PRR≥2, χ²≥4, and a≥3 co-occurrences.")
    if isinstance(sig, pd.DataFrame) and not sig.empty:
        flagged = sig[sig["signal"]]
        c1, c2, c3 = st.columns(3)
        c1.metric("Flagged signals", f"{len(flagged)}")
        if not flagged.empty:
            best_prr = flagged.loc[flagged["prr"].idxmax()]
            best_chi = flagged.loc[flagged["chi2"].idxmax()]
            c2.metric("Highest PRR", f'{best_prr["prr"]:.2f}', help=best_prr["reaction"])
            c3.metric("Highest χ²", f'{best_chi["chi2"]:.0f}', help=best_chi["reaction"])

        # Explainer
        with st.expander("How to read this (a/b/c/d, PRR, χ², rule)"):
            st.markdown(
                """
**2×2 table** for a drug–reaction in the selected date window:

|                 | Reaction present | Reaction absent |
|-----------------|------------------|-----------------|
| **Drug present**| **a**            | **b**           |
| **Drug absent** | **c**            | **d**           |

- **PRR** = (a/(a+b)) / (c/(c+d))  
- **ROR** = (a·d)/(b·c)  
- **χ²** from the 2×2 table  
- **Flag rule** (MHRA-like): **PRR ≥ 2**, **χ² ≥ 4**, **a ≥ 3**.  
These are *signals for review*, not proof of causality.
                """
            )

        dfp = sig.copy()
        dfp["log2_prr"] = (dfp["prr"].clip(lower=1e-9)).apply(lambda x: math.log(x, 2))
        dfp["neglog10_p"] = dfp["chi2"].apply(lambda x: -math.log10(max(1e-12, math.erfc(math.sqrt(x/2)))))

        # Bar: top flagged
        top_n = st.slider("Top N flagged to show in bar chart", 5, 30, 12, 1)
        flagged_sorted = dfp[dfp["signal"]].sort_values("prr", ascending=False).head(top_n)
        if not flagged_sorted.empty:
            bar = (
                alt.Chart(flagged_sorted)
                .mark_bar()
                .encode(
                    x=alt.X("prr:Q", title="PRR"),
                    y=alt.Y("reaction:N", sort="-x", title="Flagged reactions"),
                    color=alt.value("#4c78a8"),
                    tooltip=["reaction:N","a:Q","b:Q","c:Q","prr:Q","ror:Q","chi2:Q"],
                )
                .properties(height=28 * len(flagged_sorted), width="container")
                .configure_axis(labelFontSize=12, titleFontSize=12)
                .configure_view(strokeWidth=0)
            )
            _render_svg(bar)

        # Scatter plots
        st.markdown("### Scatter: log₂(PRR) vs −log₁₀(p-value)")
        sc1 = (
            alt.Chart(dfp)
            .mark_circle(size=80, opacity=0.85)
            .encode(
                x=alt.X("log2_prr:Q", title="log₂(PRR)"),
                y=alt.Y("neglog10_p:Q", title="−log₁₀(p) from χ²"),
                color=alt.Color("signal:N", scale=alt.Scale(domain=[True, False], range=["#2ca02c", "#999999"]),
                                title="Flagged"),
                tooltip=["reaction:N","a:Q","b:Q","c:Q","prr:Q","chi2:Q"],
            )
            .properties(height=360, width="container")
            .configure_axis(labelFontSize=12, titleFontSize=12)
            .configure_view(strokeWidth=0)
        )
        _render_svg(sc1)

        st.markdown("### Scatter: co-occurrence count (a) vs PRR")
        sc2 = (
            alt.Chart(dfp)
            .mark_circle(size=80, opacity=0.85)
            .encode(
                x=alt.X("a:Q", title="Co-occurrences (a)"),
                y=alt.Y("prr:Q", title="PRR"),
                color=alt.Color("signal:N", scale=alt.Scale(domain=[True, False], range=["#2ca02c", "#999999"]),
                                title="Flagged"),
                tooltip=["reaction:N","a:Q","prr:Q","chi2:Q"],
            )
            .properties(height=320, width="container")
            .configure_axis(labelFontSize=12, titleFontSize=12)
            .configure_view(strokeWidth=0)
        )
        _render_svg(sc2)

        # 3D scatter (WebGL)
        st.markdown("### 3D: signals cube (log₂(PRR), −log₁₀(p), log₁₀(a+1))")
        df3 = dfp.copy()
        x = df3["log2_prr"].astype(float)
        y = df3["neglog10_p"].astype(float)
        z = np.log10(df3["a"].astype(float) + 1.0)
        sizes_raw = df3["a"].astype(float).values
        sizeref = 2.0 * sizes_raw.max() / (40.0 ** 2) if sizes_raw.size and sizes_raw.max() > 0 else 1.0

        fig3d = go.Figure(
            data=[
                go.Scatter3d(
                    x=x, y=y, z=z,
                    mode="markers",
                    marker=dict(
                        size=sizes_raw, sizemode="area", sizeref=sizeref, sizemin=3,
                        color=df3["log2_prr"], colorscale="Viridis", showscale=True,
                        opacity=0.95,
                        line=dict(width=0.8, color="rgba(0,0,0,0.6)")
                    ),
                    text=df3["reaction"],
                    customdata=np.stack(
                        [df3["a"].values, df3["prr"].values, df3["chi2"].values, df3["signal"].map({True:"Yes", False:"No"}).values], axis=1
                    ),
                    hovertemplate="<b>%{text}</b><br>log₂(PRR)=%{x:.2f}<br>−log₁₀(p)=%{y:.2f}<br>log₁₀(a+1)=%{z:.2f}<br>a=%{customdata[0]:,} | PRR=%{customdata[1]:.2f} | χ²=%{customdata[2]:.0f}<br>Flagged=%{customdata[3]}<extra></extra>",
                )
            ]
        )
        fig3d.update_layout(
            height=560,
            font=dict(size=13),
            scene=dict(
                xaxis_title="log₂(PRR) → disproportionality",
                yaxis_title="−log₁₀(p) → significance",
                zaxis_title="log₁₀(a+1) → frequency",
                camera=dict(eye=dict(x=1.6, y=1.6, z=1.0)),
            ),
            margin=dict(l=0, r=0, t=10, b=0),
            showlegend=False,
        )
        st.plotly_chart(fig3d, use_container_width=True, theme=None)

        # raw table
        st.dataframe(
            sig.assign(signal=sig["signal"].map({True: "✅", False: ""}))[
                ["reaction","a","b","c","d","prr","ror","chi2","signal"]
            ].style.format({"prr": "{:.2f}", "ror": "{:.2f}", "chi2": "{:.2f}"}),
            use_container_width=True, height=420
        )
        only = st.checkbox("Show only flagged signals")
        if only:
            st.dataframe(sig[sig["signal"]], use_container_width=True, height=320)
    else:
        st.caption("No signals computed (no top reactions returned).")
